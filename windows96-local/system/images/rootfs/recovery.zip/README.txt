This is the recovery environment in Windows 96 (also knows as the Kernel Interrupt Environment - KIE).

You can use it to recover a broken installation and repair boot.
Your original system drive will be mapped to X:/.

NOTE: The recovery environment is running off of a Ramdisk, so you will not be able to save anything there.
