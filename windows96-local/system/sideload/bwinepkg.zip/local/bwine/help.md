BWine Help Documentation
========================

This document contains help for BWine.

If you need support for BWine, please contact the Windows 96 Developer Team through our available communication channels. Please do not bother WineHq or BoxedWine authors, this is not an official port.

BWine in a nutshell
-------------------

BWine (also bWINE, or simply WINE) is a Wine emulator for Windows 96.
Wine is a compatibility layer for POSIX-compliant systems, which allows Windows Executables to be ran under them.

It uses the [BoxedWine](http://www.boxedwine.org/) emulator to achieve the emulation needed for Wine.
BoxedWine emulates an x86-capable processor (Pentium II/Pentium III) to run x86 Windows programs, and runs a lightweight Linux distribution under-the-hood to allow Wine to function.

Please note that BWine is not ready for daily usage, it is very experimental.
In particular, the Windows 96 File System is not able to be fully mapped as the main store for application resources, due to the lack of an asynchronous file system implementation in BoxedWine/Emscripten.

Running programs
----------------

In order to run programs under BWine, the appropriate files must be made available to BWine through the bWINE content folder.

The folder `C:/user/appdata/bWINE/ToWine`, is mapped as Drive `E:` in Wine, and its contents are loaded into bWINE upon boot. There is no live reload, and any changes made to Drive E: in bWINE will not persist.
Additionally, please note that a large number of files will cause boot to slow down, so only copy what you need.

Data persistence
----------------

BWine offers data persistence in Drive `D:`, meaning that any contents created there will be saved for next boot. Please note that it has a very small capacity, due to the basic storage backend used.

Wine versions
-------------
BWine offers several Wine versions to choose from.
You can use these versions to fine-tune which Wine base will work best for your application needs.
Please note that newer versions present an increased emulation complexity and memory constraint, so we advise you to stick to the lowest supported version if you can.

The default Wine version selected by bWINE will be `Wine 3.1`, which we believe to be the best balance in terms of compatibility and emulation complexity.

To choose a Wine version, open the `Version Manager` in the `Wine` program group.

A typical BWine setup
---------------------

If you like to keep things simple, and just want to get started, below is a typical BWine setup that we recommend.

- Wine 3.1 for the best balance between app compatibility and emulation complexity.

- Utilize Drive E: as a programs folder.

- Utilize Drive D: to store program data.

Known Issues & Limitations
--------------------------
- Loading can take 10 - 15 seconds.

- Stability is questionable.

- Not all API calls will may be handled correctly.

- Applications with x86 instructions not present in the Pentium II/III will not work.

- Applications utilizing a lot of memory may cause an OOM (out-of-memory) exception in BoxedWine. Memory is not configurable at this time.

- Drive D: (for data persistence) is typically limited to 8 megabytes (a commonly imposed limit by browsers for `localStorage`).

- This is still Wine, so anything not supported by Wine will not work.